nand2tetris
===========

Selected projects from the nand2tetris curriculum. More information about the course can be found at http://www.nand2tetris.org.

The assembler, virtual machine translator, and compiler are written in Java for the Jack programming language, a Java-like language developed for educational use in this curriculum. The OS functions are implemented in Jack itself, specifically for the computer we "built" during the course.

==
###### This project was created as coursework for the University of Chicago Masters Program in Computer Science. MPCS 52011 - Introduction to Computer Systems - Fall 2014
